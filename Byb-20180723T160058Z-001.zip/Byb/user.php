<?php
	include('includes/header.php');

?>
<head>
	    <!-- Custom CSS -->
        <link href="css/custom.css" rel="stylesheet">  
        
</head>
<!-- Main Body -->
<hr>
<h1 align = "center" id="user-head">Welcome User</h1>
<hr>
<!-- //Main Body -->
<?php
	include('includes/footer.php')
?>
